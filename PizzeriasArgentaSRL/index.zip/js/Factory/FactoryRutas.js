miApp.factory('fRutas', function () {
  var RutaDesarrollo = 'http://localhost:8080/Laboratorio-IV-2016/TPlaboratorioIV2016/ws1/';
  var RutasWeb = 'http://labivaxel.esy.es/ws1/';
  var objeto = {};
  objeto.RutaDesarrollo = RutaDesarrollo;
  objeto.RutasWeb = RutasWeb;

  return objeto;


})
